# TypeScript-Programs
Actually i am started to learning TypeScript.. 
