"use strict";
var customer = {
    firstName: "Naren",
    lastName: "Karthik",
    sayHi: function () { return "Hi there  i am learning TypeScript"; }
};
console.log("Customer Object ");
console.log(customer.firstName);
console.log(customer.lastName);
console.log(customer.sayHi());
var employee = {
    firstName: "Narayanan",
    lastName: "Karthik",
    sayHi: function () { return "Hi i am Narayanan.K!!!"; }
};
console.log("Employee Object ");
console.log(employee.firstName);
console.log(employee.lastName);
