"use strict";
var num = 12;
console.log(typeof num);
for (;;) {
    console.log(This, is, an, endless, loop);
} //output: number
