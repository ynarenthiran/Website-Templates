var i, j, rows = 5;
for (i = 1; i >= rows; i--) {
    for (j = 1; j <= i; ++j) {
        console.log("*" + "\t");
    }
    console.log("\n");
}
