"use strict";
var num;
num = ["1", "2", "3", "4"];
console.log(num[0]);
console.log(num[1]);
console.log(num[1]);
console.log(num[1]);
