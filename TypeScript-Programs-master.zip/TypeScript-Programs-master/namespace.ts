// Namespace Syntax (New)
namespace TutorialPoint { 
   export function add(x, y) { console.log(x + y);} 
}