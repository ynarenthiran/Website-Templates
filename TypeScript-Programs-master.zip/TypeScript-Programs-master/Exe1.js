"use strict";
var message = "Hello World";
console.log(message);
console.log("hello world");
console.log("We are learning TypeScript");
