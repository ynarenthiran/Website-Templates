var message:string = "Hello World" 
console.log(message)
console.log("hello world")
console.log("We are learning TypeScript")



