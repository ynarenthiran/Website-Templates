var numb=4;
console.log(numb<<1);
var n=6;
console.log(n>>1);
console.log("Hello world");