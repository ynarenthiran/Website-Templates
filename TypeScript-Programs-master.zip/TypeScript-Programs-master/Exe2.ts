class HelloWorld { 
   get():void { 
      console.log("Hello World!!!") 
   } 
} 
var obj = new HelloWorld(); 
obj.get();