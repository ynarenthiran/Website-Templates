var j=100;
var i;
for(i=0;i<=j;i++)
{
    if(i%2!=0)
    {
        console.log(i+"Odd number\n");
    }
    else
    {
        console.log(i+"Even number\n");
    }
}