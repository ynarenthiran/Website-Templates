"use strict";
var num = -2;
var result = num > 0 ? "positive" : "non-positive";
console.log(result);
