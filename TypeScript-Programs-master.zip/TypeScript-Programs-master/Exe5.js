"use strict";
var str = '1';
var str2 = str; //str is now of type number 
console.log(str2);
