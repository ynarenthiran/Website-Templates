"use strict";
var str = "*";
var str1 = "#";
var i, j;
for (i = 0; i < 5; i++) {
    for (j = 0; j < i; j++) {
        console.log(str + str1);
    }
}
